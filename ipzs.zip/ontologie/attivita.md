- Introduzione sulle Ontologie (teoriche)
- Architettura del Semantic Web
  - Resource Description Framework (RDF)
  - Triple
  - Rapporto che esiste tra relazionale e tripla
  - Rappresentazioni: RDF/XML e Turtle
- Apache Jena e Fuseki Server
- Interrogazione di Triple Store: SPARQL

---
 
- Approfondimento su OWL
- Esempi Java
  - Trattare informazioni RDF
  - Eseguire query SPARQL
- Analisi Virtuoso IPZS