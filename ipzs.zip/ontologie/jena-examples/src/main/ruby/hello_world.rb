#!/usr/bin/ruby

puts 'Hello World!'