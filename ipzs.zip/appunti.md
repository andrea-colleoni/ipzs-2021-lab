https://meet.google.com/xpe-mccz-vyz

Ontologie

 *   Nozioni su Ontologie
 https://www.obitko.com/tutorials/ontologies-semantic-web/introduction.html
 http://www-ksl.stanford.edu/kst/what-is-an-ontology.html
 http://ontologydesignpatterns.org/wiki/Main_Page

 *   Ontologie in ambito giuridico

 *   Strumenti per la creazione di una ontologia
 https://hub.docker.com/r/blankdots/jena-fuseki/

 *   Tecnologie relative alle ontologie: ad es. RDF, OWL, SPARQL, Apache JENA, Piattaforma Virtuoso Community

 *   Standard di rappresentazione di norme in rete: ad es. Akoma Ntoso, Normeinrete, European Legislation Identifier,