# Stardog Tutorial data

This repository contains data, mappings and queries referenced in [Stardog tutorials](https://www.stardog.com/tutorials/). 
