# Virtual Graph Mappings

Data that accompanies the [Virtual Graph Mappings](https://www.stardog.com/tutorials/data-mappings/) tutorial.
